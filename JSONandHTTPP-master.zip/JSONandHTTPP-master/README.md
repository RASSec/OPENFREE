# Json2Dict
Burp Suite Plugin: Convert the json text that returns the body into HTTP request parameters.
